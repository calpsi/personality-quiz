// Specimen meshes arrive as indexed triangles with their museum colours. Build
// one retained p5 geometry per material, then light, orbit and display in WEBGL.
function mountSpecimenSketch(host, parts, reduced) {
  let observer;
  const sketch = new p5(p => {
    let specimen, angle = -.15, zoom = 1;
    p.setup = () => {
      const canvas = p.createCanvas(host.clientWidth, host.clientHeight, p.WEBGL);
      canvas.elt.setAttribute('aria-label', 'Your specimen in its glass display case');
      p.pixelDensity(Math.min(1.5,window.devicePixelRatio || 1));
      p.frameRate(reduced ? 20 : 40);
      specimen = p.buildGeometry(() => {
        p.noStroke();
        for (const part of parts) {
          p.fill(part.color);
          p.beginShape(p.TRIANGLES);
          for (const i of part.indices) {
            const j=i*3;
            p.normal(part.normals[j],-part.normals[j+1],part.normals[j+2]);
            p.vertex(part.vertices[j],-part.vertices[j+1],part.vertices[j+2]);
          }
          p.endShape();
        }
      });
      observer = new ResizeObserver(()=>p.resizeCanvas(host.clientWidth,host.clientHeight));
      observer.observe(host);
      canvas.mouseWheel(e=>{zoom=p.constrain(zoom-e.deltaY*.001,.75,1.5);return false;});
    };
    p.mouseDragged=()=>{if(p.mouseX>=0&&p.mouseX<p.width&&p.mouseY>=0&&p.mouseY<p.height) angle+=(p.mouseX-p.pmouseX)*.008;};
    p.draw=()=>{
      p.clear();p.ambientLight(165,154,132);p.directionalLight(255,230,177,-.4,.6,-1);
      p.rotateX(-.07);p.rotateY(angle+(reduced?0:p.sin(p.millis()*.00035)*.13));
      p.scale(Math.min(p.width/3.2,p.height/2.9)*zoom);
      p.noStroke();p.model(specimen);
      function block(x,y,z,w,h,d,color){p.push();p.translate(x,y,z);p.fill(color);p.box(w,h,d);p.pop();}
      block(0,.8,0,2.15,.16,1.35,'#67452e');
      for(const x of [-1,1])for(const z of [-.63,.63])block(x,-.1,z,.035,1.8,.035,'#c3a371');
      block(0,-1,0,2.1,.055,1.36,'#ae905b');
      block(0,-.1,.64,2,1.75,.005,p.color(213,232,211,24));
    };
  },host);
  return ()=>{observer?.disconnect();sketch.remove();};
}

// Editable p5.js scene. The asset renderer supplies the rigged GLB animation,
// and p5 draws the scene, atmosphere, and a brief ripple when the visitor taps.
function mountMuseumSketch(host, initialise) {
  let disposeScene;
  const sketch = new p5(p => {
    let scene;
    let ripple;
    let observer;
    p.setup = () => {
      const canvas = p.createCanvas(Math.max(1, host.clientWidth), Math.max(1, host.clientHeight));
      p.pixelDensity(Math.min(window.devicePixelRatio || 1, 1.5));
      p.frameRate(45);
      scene = initialise(canvas.elt);
      if (!scene) { p.noLoop(); return; }
      const resize = () => {
        p.resizeCanvas(Math.max(1, host.clientWidth), Math.max(1, host.clientHeight), true);
        scene.resize();
      };
      observer = new ResizeObserver(resize);
      observer.observe(host);
      const tap = e => {
        const bounds = canvas.elt.getBoundingClientRect();
        ripple = {x:e.clientX-bounds.left,y:e.clientY-bounds.top,start:p.millis()};
      };
      canvas.elt.addEventListener('pointerdown', tap);
      disposeScene = () => {
        canvas.elt.removeEventListener('pointerdown', tap);
        observer.disconnect();
        scene.dispose();
      };
    };
    p.draw = () => {
      if (!scene || document.hidden) return;
      scene.tick(Math.min(p.deltaTime / 1000, .05));
      p.clear();
      p.drawingContext.drawImage(scene.surface,0,0,p.width,p.height);
      if (scene.reduced || !scene.exploring) return;
      // Small amber motes in the lamplight. Each retains a stable drift path.
      const t = p.millis() / 1000;
      p.noStroke();
      for (let i=0;i<12;i++) {
        p.fill(246,215,153,18+12*p.sin(t+i));
        p.circle(p.noise(i*13,t*.025)*p.width,p.noise(i*7+55,t*.018)*p.height,2);
      }
      if (ripple) {
        const progress=(p.millis()-ripple.start)/360;
        if (progress>=1) ripple=null;
        else {p.noFill();p.stroke(245,222,172,110*(1-progress));p.strokeWeight(1);p.circle(ripple.x,ripple.y,6+22*progress);}
      }
    };
  },host);
  return () => {disposeScene?.();sketch.remove();};
}
